#include <sqlcli.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define SQL_LEN 1000
#define MSG_LEN 1024

SQLHENV  env;  // Environment Handle
SQLHDBC  dbc;  // Connection Handle
int      conn_flag;

SQLRETURN alloc_handle();
SQLRETURN db_connect();
void free_handle();

SQLRETURN execute_update2();
SQLRETURN execute_select();
SQLRETURN commit();

void execute_err(SQLHDBC aCon, SQLHSTMT aStmt, char* q);

char *table_name = "TEST_GTX";
int tx_level = 0;

int main(int argc, char **argv)
{
    SQLRETURN    rc;
    int          count = 0;

    env = SQL_NULL_HENV;
    dbc = SQL_NULL_HDBC;
    conn_flag = 0;

    if (argc > 1)
    {
        tx_level = atoi(argv[1]);
    }

    /* allocate handle */
    rc = alloc_handle();
    if ( rc != SQL_SUCCESS )
    {
        free_handle();
        exit(1);
    }

    /* Connect to Altibase Server */
    rc = db_connect();
    if ( rc != SQL_SUCCESS )
    {
        free_handle();
        exit(1);
    }

    /* transaction */
    while(1)
    {
        rc = execute_update2();
        if ( rc != SQL_SUCCESS )
        {
            free_handle();
            exit(1);
        }

        rc = commit();
        if ( rc != SQL_SUCCESS )
        {
            free_handle();
            exit(1);
        }

        if( (++count) %  1000 == 0 )
        {
            printf("count : %d\n", count);
        }
    }

    /* disconnect, free handles */
    free_handle();

    return 0;
}

static void print_diagnostic(SQLSMALLINT aHandleType, SQLHANDLE aHandle)
{
    SQLRETURN   rc;
    SQLSMALLINT sRecordNo;
    SQLCHAR     sSQLSTATE[6];
    SQLCHAR     sMessage[2048];
    SQLSMALLINT sMessageLength;
    SQLINTEGER  sNativeError;

    sRecordNo = 1;

    while ((rc = SQLGetDiagRec(aHandleType,
                               aHandle,
                               sRecordNo,
                               sSQLSTATE,
                               &sNativeError,
                               sMessage,
                               sizeof(sMessage),
                               &sMessageLength)) != SQL_NO_DATA)
    {
        printf("Diagnostic Record %d\n", sRecordNo);
        printf("     SQLSTATE     : %s\n", sSQLSTATE);
        printf("     Message text : %s\n", sMessage);
        printf("     Message len  : %d\n", sMessageLength);
        printf("     Native error : 0x%X\n", sNativeError);

        if (rc != SQL_SUCCESS && rc != SQL_SUCCESS_WITH_INFO)
        {
            break;
        }

        sRecordNo++;
    }
}

void execute_err(SQLHDBC aCon, SQLHSTMT aStmt, char* q)
{
    printf("Error : %s\n",q);

    if (aStmt == SQL_NULL_HSTMT)
    {
        if (aCon != SQL_NULL_HDBC)
        {
            print_diagnostic(SQL_HANDLE_DBC, aCon);
        }
    }
    else
    {
        print_diagnostic(SQL_HANDLE_STMT, aStmt);
    }
}


SQLRETURN alloc_handle()
{
    /* allocate Environment handle */
    if (SQLAllocEnv(&env) != SQL_SUCCESS)
    {
        printf("SQLAllocEnv error!!\n");
        return SQL_ERROR;
    }

    /* allocate Connection handle */
    if (SQLAllocConnect(env, &dbc) != SQL_SUCCESS) 
    {
        printf("SQLAllocConnect error!!\n");
        return SQL_ERROR;
    }
    return SQL_SUCCESS;
}

void free_handle()
{
    if ( conn_flag == 1 )
    {
        /* close connection */
        SQLDisconnect( dbc );
    }
    /* free connection handle */
    if ( dbc != NULL )
    {
        SQLFreeConnect( dbc );
    }
    if ( env != NULL )
    {
        SQLFreeEnv( env );
    }
}

SQLRETURN db_connect()
{
    char    *USERNAME = "test";        // user name
    char    *PASSWD   = "test";    // user password
    char    *NLS      = "utf8";   // NLS_USE ( KO16KSC5601, US7ASCII )
    char     connStr[1024];
    SQLINTEGER  option;

    sprintf(connStr,
            "DSN=127.0.0.1;UID=%s;PWD=%s;CONNTYPE=%d;NLS_USE=%s;PORT_NO=20300",
            USERNAME, PASSWD, 1, NLS);

    /* establish connection */
    if (SQLDriverConnect( dbc, NULL, (SQLCHAR *)connStr, SQL_NTS,
                          NULL, 0, NULL,
                          SQL_DRIVER_NOPROMPT ) != SQL_SUCCESS)
    {
        execute_err(dbc, SQL_NULL_HSTMT, "SQLDriverConnect");
        return SQL_ERROR;
    }

    conn_flag = 1;

    if (tx_level == 1)
    {
        option = ALTIBASE_SHARD_SINGLE_NODE_TRANSACTION;
    }
    else if (tx_level == 2)
    {
        option = ALTIBASE_SHARD_MULTIPLE_NODE_TRANSACTION;
    }
    else if (tx_level == 3)
    {
        option = ALTIBASE_SHARD_GLOBAL_TRANSACTION;
    }
    else
    {
        option = 0;
    }

    /* AutoCommit off */
    if (SQLSetConnectAttr(dbc, SQL_ATTR_AUTOCOMMIT,
                          (void*)SQL_AUTOCOMMIT_OFF, option) != SQL_SUCCESS)
    {
        execute_err(dbc, SQL_NULL_HSTMT, "Autocommit OFF");
        return SQL_ERROR;
    }

    return SQL_SUCCESS;
}

SQLRETURN execute_update2()
{
    SQLHSTMT     stmt1 = SQL_NULL_HSTMT;
    SQLHSTMT     stmt2 = SQL_NULL_HSTMT;
    SQLRETURN    rc;
    char         query1[SQL_LEN];
    char         query2[SQL_LEN];

    /* allocate Statement handle */
    if (SQL_ERROR == SQLAllocStmt(dbc, &stmt1)) 
    {
        printf("SQLAllocStmt stmt1 error!!\n");
        return SQL_ERROR;
    }

    if (SQL_ERROR == SQLAllocStmt(dbc, &stmt2)) 
    {
        printf("SQLAllocStmt stmt2 error!!\n");
        return SQL_ERROR;
    }

    sprintf(query1,"UPDATE %s SET AMOUNT=AMOUNT-50 WHERE ACCOUNT = 'A'", table_name);
    sprintf(query2,"UPDATE %s SET AMOUNT=AMOUNT+50 WHERE ACCOUNT = 'B'", table_name);

    if (SQLPrepare(stmt1, (SQLCHAR *)query1, SQL_NTS) != SQL_SUCCESS)
    {
        execute_err(dbc, stmt1, query1);
        SQLFreeStmt(stmt1, SQL_DROP);
        return SQL_ERROR;
    }

    if (SQLPrepare(stmt2, (SQLCHAR *)query2, SQL_NTS) != SQL_SUCCESS)
    {
        execute_err(dbc, stmt2, query2);
        SQLFreeStmt(stmt2, SQL_DROP);
        return SQL_ERROR;
    }

    rc = SQLExecute(stmt1);
    if (rc != SQL_SUCCESS)
    {
        execute_err(dbc, stmt1, "SQLExecute stmt1 : ");
        SQLFreeStmt(stmt1, SQL_DROP);
        return SQL_ERROR;
    }

    rc = SQLExecute(stmt2);
    if (rc != SQL_SUCCESS)
    {
        execute_err(dbc, stmt2, "SQLExecute stmt1 : ");
        SQLFreeStmt(stmt2, SQL_DROP);
        return SQL_ERROR;
    }

    SQLFreeStmt(stmt1, SQL_DROP);
    SQLFreeStmt(stmt2, SQL_DROP);

    return SQL_SUCCESS;
}

SQLRETURN commit()
{
    SQLRETURN    rc;

    rc = SQLEndTran(SQL_HANDLE_DBC, dbc, SQL_COMMIT);
    if (rc != SQL_SUCCESS)
    {
        execute_err(dbc, SQL_NULL_HSTMT, "SQLEndTran : ");
        return SQL_ERROR;
    }

    return SQL_SUCCESS;
}

