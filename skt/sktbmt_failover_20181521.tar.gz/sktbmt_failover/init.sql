update test set cnt = 0;
commit;

alter system checkpoint;
alter system checkpoint;
alter system checkpoint;
