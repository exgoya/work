gsqlnet --as sysdba --dsn=g1n1 --silent --import init.sql
