sh init.sh

./sktperf g1n1 $1     1 15000 250000 &
./sktperf g2n1 $1 15001 30000 250000 &
